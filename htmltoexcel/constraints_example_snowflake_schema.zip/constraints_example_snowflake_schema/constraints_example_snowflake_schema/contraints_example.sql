{{
  config(
    materialized = "table_with_constraints"
  )
}}

select 
  1 as id, 
  'blue' as color, 
  cast('2019-01-01' as date) as date_day


-- Expected output
{# create or replace TRANSIENT TABLE ANALYTICS.DBT_SUNG.CONSTRAINTS_EXAMPLE (
	ID NUMBER(38,0) NOT NULL,
	COLOR VARCHAR(16777216),
	DATE_DAY DATE DEFAULT CURRENT_DATE()
); #}