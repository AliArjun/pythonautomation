

        create or replace transient table ANALYTICS.dbt_sung.constraints_example  
        
        
          (
          
            
            id NUMBER(38,0)   not null ,
          
            
            color VARCHAR(3)    ,
          
            
            date_day date default CURRENT_DATE()   
          
        )
        
        as
        (

select 
  1 as id, 
  'blue' as color, 
  cast('2019-01-01' as date) as date_day


-- Expected output

        );
      